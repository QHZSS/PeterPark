<template></template>
<script>
  // 定义一些公共的属性和方法
  const MessageWatchFlag = false;
  const IoTMessageWatchFlag = false;
  const ParkingLotUserWatchFlag = true;
  const ParkingOrderWatchFlag = false;
  const ParkingSpaceOwnerWatchFlag = false;
  const ParkingSpaceWatchFlag = false;
  // 暴露出这些属性和方法
  export default {
    MessageWatchFlag,
    IoTMessageWatchFlag,
    ParkingLotUserWatchFlag,
    ParkingOrderWatchFlag,
    ParkingSpaceOwnerWatchFlag,
    ParkingSpaceWatchFlag
  }
</script>
<style scoped></style>
